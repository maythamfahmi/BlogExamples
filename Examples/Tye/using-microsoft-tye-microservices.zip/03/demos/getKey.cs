private static string GetKey(string name, string? binding)
{
	return binding == null ? name : $"{name}:{binding}";
}