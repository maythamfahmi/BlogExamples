public static Uri? GetServiceUri(this IConfiguration configuration, string name, string? binding = null)
        {
            var key = GetKey(name, binding);

            var host = configuration[$"service:{key}:host"];
            var port = configuration[$"service:{key}:port"];
            var protocol = configuration[$"service:{key}:protocol"] ?? "http";

            if (string.IsNullOrEmpty(host) || port == null)
            {
                return null;
            }

            if (IPAddress.TryParse(host, out IPAddress address) && address.AddressFamily == AddressFamily.InterNetworkV6)
            {
                host = "[" + host + "]";
            }

            return new Uri(protocol + "://" + host + ":" + port + "/");
        }